import Form from "./components/formulario.js"; // Módulo del formulario
import tabla from "./components/tabla.js"; // Módulo de la tabla
import cards from "./components/cards.js"; // Módulo de las tarjetas

document.addEventListener("DOMContentLoaded", () => {
  const mostrarPostBtn = document.getElementById("mostrarPost"); // Botón Mostrar Post

  // Función para mostrar y actualizar los datos
  const mostrarYActualizarPost = async () => {
    try {
      const response = await fetch("http://localhost:3000/tareas"); // Solicitud GET al servidor
      if (!response.ok) throw new Error("Error al recuperar las tareas del servidor.");

      const tareas = await response.json(); // Convertimos la respuesta en JSON
      console.log("Tareas recuperadas:", tareas);

      // Actualizamos la tabla y las tarjetas con las tareas
      tabla.updateTasks(tareas);
      cards.updateTasks(tareas);
    } catch (error) {
      console.error("Error al mostrar y actualizar los posts:", error.message);
    }
  };

  // Evento para mostrar y actualizar los datos al hacer clic en el botón
  mostrarPostBtn.addEventListener("click", mostrarYActualizarPost);
});