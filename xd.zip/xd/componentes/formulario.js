// Módulo Formulario
const Form = (() => {
    // Recuperamos elementos del formulario y sus inputs
    const form = document.querySelector("[data-form]");
    const inputTask = document.querySelector("[data-input-task]");
    const inputDescription = document.querySelector("[data-input-descripcion]");
    const inputDate = document.querySelector("[data-input-fecha]");
    const inputPrioridad = document.querySelector("[data-input-prioridad]");

    // Función para obtener los datos ingresados en el formulario
    const datosForm = () => {
        return {
            task: inputTask.value.trim(),
            description: inputDescription.value.trim(),
            date: inputDate.value.trim(),
            priority: parseInt(inputPrioridad.value.trim(), 10), // Convertimos la prioridad en entero
        };
    };

    // Validar los datos antes de enviarlos
    const validarDatos = (data) => {
        if (!data.task || !data.description || !data.date || isNaN(data.priority) || data.priority <= 0) {
            alert("Por favor, completa todos los campos y asegúrate de que la prioridad sea un número positivo.");
            return false;
        }
        return true;
    };

    // Enviar datos al servidor (POST)
    const enviarAlServidor = async (data) => {
        try {
            const response = await fetch("http://localhost:3000/tareas", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(data), // Enviamos los datos al servidor
            });

            if (!response.ok) throw new Error("Error al enviar los datos al servidor.");

            const nuevaTarea = await response.json();
            console.log("Tarea guardada:", nuevaTarea);

            // Actualizamos la interfaz después de confirmar el POST
            actualizarInterfaz();
        } catch (error) {
            console.error("Error:", error.message);
        }
    };

    // Actualizar la interfaz después de agregar una tarea
    const actualizarInterfaz = async () => {
        try {
            const response = await fetch("http://localhost:3000/tareas"); // Recuperamos las tareas del servidor
            if (!response.ok) throw new Error("Error al recuperar las tareas del servidor.");

            const tareas = await response.json(); // Convertimos las tareas en JSON

            // Actualizamos la tabla y las tarjetas
            tabla.updateTasks(tareas); // Regenera la tabla
            cards.updateTasks(tareas); // Regenera las tarjetas
        } catch (error) {
            console.error("Error:", error.message);
        }
    };

    // Limpia los datos ingresados en el formulario
    const resetFormulario = () => {
        inputTask.value = "";
        inputDescription.value = "";
        inputDate.value = "";
        inputPrioridad.value = "";
    };

    // Configurar el evento del formulario al enviar datos
    const setDatos = (callback) => {
        form.addEventListener("submit", (evento) => {
            evento.preventDefault(); // Evitamos la acción por defecto del formulario
            const datos = datosForm(); // Obtenemos los datos del formulario
            if (validarDatos(datos)) {
                enviarAlServidor(datos); // Enviamos los datos al servidor
                callback(datos); // Ejecutamos el callback para actualizar la tabla
                resetFormulario(); // Limpiamos el formulario
            }
        });
    };

    return { setDatos }; // Exportamos la función para usarla en otros módulos
})();

export default Form;